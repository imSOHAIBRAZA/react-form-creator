import React from "react";

const TextField = ({ error, label, name,type, placeholder, value, onChange }:any) => {

    const renderError = error ? (
        <strong>{error}</strong>
    ) : null;

    return (
        <div>
            <label>{label}</label>
            <br />
            <input
                type={type}
                name={name}
                placeholder={placeholder}
                value={value}
                onChange={onChange}
            />
            {renderError}
        </div>
    );

}

export default TextField;
