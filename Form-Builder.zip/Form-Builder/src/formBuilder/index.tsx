import { useState } from "react";
import { Formik } from "formik";
import TextField from "./fields/textField";
import { createYupSchema } from "./yupSchemaCreator";
import * as yup from "yup";

const fieldMap = {
    text: TextField
};

const FormElementsLayout = (props: any) => {
    const { fields, errors, values, handleChange,styles } = props
    return (
        <>
            {
                fields.map((item, index) => {

                    // const Component = fieldMap[item.type];
                    const Component = TextField;
                    let error = errors.hasOwnProperty(item.id) && errors[item.id];

                    if (item.type) {
                        return (
                            <>
                                <Component
                                    key={index}
                                    label={item.label}
                                    name={item.id}
                                    class={item.}
                                    type={item.type}
                                    placeholder={item.placeholder}
                                    value={values[item.id]}
                                    onChange={handleChange}
                                    error={error}
                                    styles={styles}
                                />
                            </>
                        );
                    }
                    return "";
                })
            }
        </>
    )
}




const FormBuilder = ({ fields, buttonText = "Submit", onsubmitCallback }: any) => {
    const [initialValues] = useState<any>({});

    fields.forEach(item => {
        initialValues[item.id] = item.value || "";
    });

    const yepSchema = fields.reduce(createYupSchema, {});
    const validateSchema = yup.object().shape(yepSchema);


    return (
        <div className="form">
            <h1>Form here</h1>
            <Formik
                initialValues={initialValues}
                validationSchema={validateSchema}
                onSubmit={(values, actions) => {
                    onsubmitCallback(values, actions)
                }}
            >

                {props => (
                    <form onSubmit={props.handleSubmit}>
                        <FormElementsLayout fields={fields} {...props} />
                        <button type="submit">{buttonText}</button>
                    </form>
                )}

            </Formik>
        </div>
    );
}


export default FormBuilder;
